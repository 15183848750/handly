// Handly — Popup Controller v1.6

const $ = (sel) => document.querySelector(sel);
const $$ = (sel) => document.querySelectorAll(sel);

async function getCurrentTab() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  return tab;
}

function togglePanel(panelId) {
  $$('.sub-panel, .table-list').forEach(p => p.classList.remove('active'));
  const panel = $(`#${panelId}`);
  if (panel) panel.classList.add('active');
}

function showStatus(msg, type = 'loading') {
  const el = $('#status');
  el.className = `status ${type}`;
  el.textContent = msg;
  if (type === 'success' || type === 'error') {
    setTimeout(() => { el.className = 'status'; el.textContent = ''; }, 4000);
  }
}

// ========== Screenshot ==========
$('#tool-screenshot').addEventListener('click', () => togglePanel('panel-screenshot'));

$$('.preset-btn').forEach(btn => {
  btn.addEventListener('click', async () => {
    const preset = btn.dataset.preset;
    showStatus('正在截图...', 'loading');
    try {
      const dataUrl = await chrome.tabs.captureVisibleTab(null, { format: 'png' });
      const img = await new Promise((resolve, reject) => {
        const image = new Image();
        image.onload = () => resolve(image);
        image.onerror = () => reject(new Error('图片加载失败'));
        image.src = dataUrl;
      });
      const config = ScreenshotBeautifier.presets[preset] || ScreenshotBeautifier.presets.clean;
      const P = config.padding, R = config.radius;
      const W = img.width + P * 2, H = img.height + P * 2;
      const canvas = document.createElement('canvas');
      canvas.width = W; canvas.height = H;
      const ctx = canvas.getContext('2d');

      if (config.bg) {
        ctx.fillStyle = config.bg.startsWith('linear-gradient')
          ? parseGradient(ctx, config.bg, W, H) : config.bg;
        ctx.fillRect(0, 0, W, H);
      }
      if (R > 0 && config.shadow) {
        ctx.save();
        ctx.shadowColor = 'rgba(0,0,0,0.2)'; ctx.shadowBlur = 24;
        ctx.shadowOffsetX = 0; ctx.shadowOffsetY = 6;
        ctx.fillStyle = '#000';
        ctx.beginPath(); roundRect(ctx, P, P, img.width, img.height, R); ctx.fill();
        ctx.restore();
      }
      ctx.save();
      ctx.beginPath(); roundRect(ctx, P, P, img.width, img.height, R); ctx.clip();
      ctx.drawImage(img, P, P, img.width, img.height);
      ctx.restore();

      const a = document.createElement('a');
      a.download = `handly-${config.name}-${Date.now()}.png`;
      a.href = canvas.toDataURL('image/png');
      document.body.appendChild(a); a.click(); document.body.removeChild(a);
      showStatus('✅ 截图已保存！', 'success');
    } catch (err) {
      showStatus('❌ 截图失败: ' + (err.message || String(err)), 'error');
    }
  });
});

function roundRect(ctx, x, y, w, h, r) {
  ctx.moveTo(x + r, y); ctx.lineTo(x + w - r, y);
  ctx.quadraticCurveTo(x + w, y, x + w, y + r);
  ctx.lineTo(x + w, y + h - r); ctx.quadraticCurveTo(x + w, y + h, x + w - r, y + h);
  ctx.lineTo(x + r, y + h); ctx.quadraticCurveTo(x, y + h, x, y + h - r);
  ctx.lineTo(x, y + r); ctx.quadraticCurveTo(x, y, x + r, y);
}

function parseGradient(ctx, css, W, H) {
  const m = css.match(/linear-gradient\((\d+)deg,\s*(.+)\)/);
  if (!m) return css;
  const angle = parseInt(m[1]) * Math.PI / 180;
  const colors = m[2].split(',').map(s => s.trim());
  const grad = ctx.createLinearGradient(
    W/2 - Math.cos(angle) * W/2, H/2 - Math.sin(angle) * H/2,
    W/2 + Math.cos(angle) * W/2, H/2 + Math.sin(angle) * H/2
  );
  colors.forEach((c, i) => grad.addColorStop(i / (colors.length - 1), c));
  return grad;
}

// ========== Table Export (v1.6 — optimized scan, user decides download) ==========
$('#tool-export').addEventListener('click', () => {
  togglePanel('panel-export');
  scanAndShowTables();
});

let cachedSheets = []; // cache for download
let cachedHost = '';

async function scanAndShowTables() {
  const panel = $('#panel-export');
  panel.innerHTML = '<p style="font-size:0.85rem;color:var(--muted);padding:8px;text-align:center;">🔍 正在扫描本页所有表格...</p>';
  showStatus('正在扫描...', 'loading');

  try {
    const tab = await getCurrentTab();
    cachedHost = new URL(tab.url).hostname.replace(/^www\./, '');

    const startTime = performance.now();

    const results = await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: () => {
        const tables = document.querySelectorAll('table');
        const sheets = [];
        const TOTAL = tables.length;
        let scanned = 0, skippedHidden = 0, skippedTiny = 0;

        for (let ti = 0; ti < TOTAL; ti++) {
          const table = tables[ti];

          // ---- Visibility check ----
          // Skip display:none / visibility:hidden
          const style = window.getComputedStyle(table);
          if (style.display === 'none' || style.visibility === 'hidden') {
            skippedHidden++;
            continue;
          }
          // Also skip zero-size tables
          if (table.offsetWidth === 0 && table.offsetHeight === 0 && table.clientHeight === 0) {
            skippedHidden++;
            continue;
          }

          // ---- Skip layout tables (no semantic structure) ----
          const hasThead = !!table.querySelector('thead');
          const hasTh = !!table.querySelector('th');
          const trCount = table.querySelectorAll('tr').length;
          // Tables with no thead, no th, and few rows are probably layout
          if (!hasThead && !hasTh && trCount < 3) {
            skippedTiny++;
            continue;
          }

          // ---- Title detection ----
          let title = '';
          // 1. aria-label
          title = table.getAttribute('aria-label') || '';
          // 2. id attribute (convert camelCase/kebab to spaces)
          if (!title && table.id) {
            title = table.id.replace(/[-_]/g, ' ').replace(/([a-z])([A-Z])/g, '$1 $2');
          }
          // 3. caption
          if (!title) {
            const cap = table.querySelector('caption');
            if (cap) title = cap.textContent.trim();
          }
          // 4. data-* attributes
          if (!title) {
            title = table.getAttribute('data-title') || table.getAttribute('data-label') || '';
          }
          // 5. preceding heading
          if (!title) {
            let el = table.previousElementSibling;
            while (el && !/^H[1-6]$/.test(el.tagName)) el = el.previousElementSibling;
            if (el) title = el.textContent.trim();
          }
          // 6. parent section/article heading
          if (!title) {
            const section = table.closest('section, article');
            if (section) {
              const h = section.querySelector('h1, h2, h3, h4, h5, h6');
              if (h) title = h.textContent.trim();
            }
          }

          // ---- Header detection ----
          let headerRows = 0;
          const thead = table.querySelector('thead');
          if (thead) {
            headerRows = thead.querySelectorAll('tr').length;
          } else {
            // Count consecutive th-only rows at the top
            const trs = table.querySelectorAll('tr');
            for (let r = 0; r < Math.min(trs.length, 3); r++) {
              const ths = trs[r].querySelectorAll('th');
              if (ths.length > 0 && ths.length >= trs[r].querySelectorAll('td').length) {
                headerRows++;
              } else {
                break;
              }
            }
          }

          // ---- Extract cells (optimized for speed) ----
          const rows = [];
          const trs = table.querySelectorAll('tr');
          let maxCols = 0;

          for (let r = 0; r < trs.length; r++) {
            const cells = trs[r].querySelectorAll('th, td');
            if (cells.length === 0) continue;

            const row = [];
            for (let c = 0; c < cells.length; c++) {
              const td = cells[c];
              // Fast text extraction
              let val = td.textContent;
              // Collapse whitespace
              val = val.replace(/[\s\u00A0]+/g, ' ').trim();
              const colspan = parseInt(td.getAttribute('colspan')) || 1;
              row.push(val);
              // Pad colspan
              for (let p = 1; p < colspan; p++) row.push('');
            }
            if (row.length > 0) {
              rows.push(row);
              if (row.length > maxCols) maxCols = row.length;
            }
          }

          if (rows.length < 2) { skippedTiny++; continue; }

          // Normalize all rows to same width
          for (let r = 0; r < rows.length; r++) {
            while (rows[r].length < maxCols) rows[r].push('');
          }

          scanned++;
          const name = (title && title.length <= 28) ? title : ('表格' + scanned);
          sheets.push({ name, rows, headerRows });
        }

        return {
          sheets,
          stats: { total: TOTAL, scanned, skippedHidden, skippedTiny, duration: 0 }
        };
      }
    });

    const data = results[0]?.result || {};
    cachedSheets = data.sheets || [];
    const stats = data.stats || {};

    const elapsed = Math.round(performance.now() - startTime);
    cachedSheets._stats = { ...stats, elapsed };

    if (cachedSheets.length === 0) {
      showStatus('未找到表格', 'error');
      panel.innerHTML = `<p style="font-size:0.85rem;color:var(--muted);padding:16px;text-align:center;">
        当前页面未找到数据表格<br>
        <span style="font-size:0.7rem;">扫描了 ${stats.total || 0} 个元素，跳过 ${(stats.skippedHidden||0)+(stats.skippedTiny||0)} 个非数据表格</span><br><br>
        💡 试试打开维基百科、股票网站等<br><br>
        <button id="btn-refresh" style="padding:8px 20px;background:var(--accent);color:#fff;border:none;border-radius:6px;cursor:pointer;font-size:0.85rem;">🔄 刷新</button>
      </p>`;
      bindRefresh();
      return;
    }

    const totalRows = cachedSheets.reduce((s, sh) => s + sh.rows.length, 0);

    // Preview with download button
    panel.innerHTML = `
      <div style="padding:8px 0;">
        <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:10px;">
          <p style="font-size:0.85rem;color:var(--muted);">
            找到 <strong>${cachedSheets.length}</strong> 个表格，<strong>${totalRows}</strong> 行
            <span style="font-size:0.65rem;color:#aaa;">（${elapsed}ms）</span>
          </p>
          <button id="btn-refresh" style="padding:6px 12px;background:var(--bg);border:1px solid var(--border);border-radius:6px;cursor:pointer;font-size:0.8rem;color:var(--muted);">🔄 刷新</button>
        </div>
        <div style="max-height:160px;overflow-y:auto;margin-bottom:12px;border:1px solid var(--border);border-radius:8px;">
          ${cachedSheets.map(s => `
            <div style="display:flex;justify-content:space-between;padding:7px 10px;font-size:0.8rem;border-bottom:1px solid #f0f0f0;">
              <span>📊 <strong>${s.name}</strong>${s.headerRows > 0 ? ' <span style="color:#2563eb;font-size:0.7rem;">表头</span>' : ''}</span>
              <span style="color:var(--muted)">${s.rows.length}行 × ${(s.rows[0]||[]).length}列</span>
            </div>
          `).join('')}
        </div>
        <button id="btn-download-xlsx" style="width:100%;padding:12px;background:#16a34a;color:#fff;border:none;border-radius:8px;font-size:0.95rem;font-weight:600;cursor:pointer;">
          ⬇ 下载全部表格 (.xlsx)
        </button>
        <p style="font-size:0.7rem;color:var(--muted);text-align:center;margin-top:6px;">
          每个表格一个 Sheet · 表头自动加粗 · Excel / WPS 打开
        </p>
      </div>
    `;

    document.getElementById('btn-download-xlsx').addEventListener('click', () => {
      try {
        const buf = XLSXBuilder.build(cachedSheets);
        const blob = new Blob([buf], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.download = `handly-${cachedHost}-${new Date().toISOString().slice(0,10)}.xlsx`;
        a.href = url;
        document.body.appendChild(a); a.click(); document.body.removeChild(a);
        URL.revokeObjectURL(url);
        showStatus(`✅ 已下载 ${cachedSheets.length} 个表格！`, 'success');
      } catch (err) {
        showStatus('❌ 导出失败: ' + err.message, 'error');
      }
    });

    bindRefresh();

  } catch (err) {
    showStatus('❌ 无法访问页面: ' + err.message, 'error');
    panel.innerHTML = '<p style="font-size:0.85rem;color:var(--muted);padding:12px;text-align:center;">扫描失败，请刷新后重试</p>';
  }
}

function bindRefresh() {
  const btn = document.getElementById('btn-refresh');
  if (btn) {
    btn.addEventListener('click', (e) => {
      e.stopPropagation();
      scanAndShowTables();
    });
  }
}
