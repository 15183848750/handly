// Handly — Popup Controller v1.3

const $ = (sel) => document.querySelector(sel);
const $$ = (sel) => document.querySelectorAll(sel);

async function getCurrentTab() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  return tab;
}

function togglePanel(panelId) {
  $$('.sub-panel, .table-list').forEach(p => p.classList.remove('active'));
  const panel = $(`#${panelId}`);
  if (panel) panel.classList.add('active');
}

function showStatus(msg, type = 'loading') {
  const el = $('#status');
  el.className = `status ${type}`;
  el.textContent = msg;
  if (type === 'success' || type === 'error') {
    setTimeout(() => { el.className = 'status'; el.textContent = ''; }, 4000);
  }
}

// ========== Screenshot ==========
$('#tool-screenshot').addEventListener('click', () => togglePanel('panel-screenshot'));

$$('.preset-btn').forEach(btn => {
  btn.addEventListener('click', async () => {
    const preset = btn.dataset.preset;
    showStatus('正在截图...', 'loading');
    try {
      const dataUrl = await chrome.tabs.captureVisibleTab(null, { format: 'png' });
      const img = await new Promise((resolve, reject) => {
        const image = new Image();
        image.onload = () => resolve(image);
        image.onerror = () => reject(new Error('图片加载失败'));
        image.src = dataUrl;
      });
      const config = ScreenshotBeautifier.presets[preset] || ScreenshotBeautifier.presets.clean;
      const P = config.padding, R = config.radius;
      const W = img.width + P * 2, H = img.height + P * 2;
      const canvas = document.createElement('canvas');
      canvas.width = W; canvas.height = H;
      const ctx = canvas.getContext('2d');

      if (config.bg) {
        ctx.fillStyle = config.bg.startsWith('linear-gradient')
          ? parseGradient(ctx, config.bg, W, H) : config.bg;
        ctx.fillRect(0, 0, W, H);
      }
      if (R > 0 && config.shadow) {
        ctx.save();
        ctx.shadowColor = 'rgba(0,0,0,0.2)'; ctx.shadowBlur = 24;
        ctx.shadowOffsetX = 0; ctx.shadowOffsetY = 6;
        ctx.fillStyle = '#000';
        ctx.beginPath(); roundRect(ctx, P, P, img.width, img.height, R); ctx.fill();
        ctx.restore();
      }
      ctx.save();
      ctx.beginPath(); roundRect(ctx, P, P, img.width, img.height, R); ctx.clip();
      ctx.drawImage(img, P, P, img.width, img.height);
      ctx.restore();

      const a = document.createElement('a');
      a.download = `handly-${config.name}-${Date.now()}.png`;
      a.href = canvas.toDataURL('image/png');
      document.body.appendChild(a); a.click(); document.body.removeChild(a);
      showStatus('✅ 截图已保存！', 'success');
    } catch (err) {
      showStatus('❌ 截图失败: ' + (err.message || String(err)), 'error');
    }
  });
});

function roundRect(ctx, x, y, w, h, r) {
  ctx.moveTo(x + r, y); ctx.lineTo(x + w - r, y);
  ctx.quadraticCurveTo(x + w, y, x + w, y + r);
  ctx.lineTo(x + w, y + h - r); ctx.quadraticCurveTo(x + w, y + h, x + w - r, y + h);
  ctx.lineTo(x + r, y + h); ctx.quadraticCurveTo(x, y + h, x, y + h - r);
  ctx.lineTo(x, y + r); ctx.quadraticCurveTo(x, y, x + r, y);
}

function parseGradient(ctx, css, W, H) {
  const m = css.match(/linear-gradient\((\d+)deg,\s*(.+)\)/);
  if (!m) return css;
  const angle = parseInt(m[1]) * Math.PI / 180;
  const colors = m[2].split(',').map(s => s.trim());
  const grad = ctx.createLinearGradient(
    W/2 - Math.cos(angle) * W/2, H/2 - Math.sin(angle) * H/2,
    W/2 + Math.cos(angle) * W/2, H/2 + Math.sin(angle) * H/2
  );
  colors.forEach((c, i) => grad.addColorStop(i / (colors.length - 1), c));
  return grad;
}

// ========== Table Export (v1.3 — one-click XLSX with all tables) ==========
$('#tool-export').addEventListener('click', async () => {
  togglePanel('panel-export');
  const panel = $('#panel-export');
  panel.innerHTML = '<p style="font-size:0.85rem;color:var(--muted);padding:8px;text-align:center;">🔍 正在扫描本页所有表格...</p>';
  showStatus('正在导出本页全部表格...', 'loading');

  try {
    const tab = await getCurrentTab();

    // Extract ALL tables with their full data
    const results = await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: () => {
        const tables = document.querySelectorAll('table');
        const sheets = [];

        tables.forEach((table) => {
          if (table.offsetParent === null && table.clientHeight === 0) return;
          const trs = table.querySelectorAll('tr');
          if (trs.length < 2) return;

          // Find table name
          let title = table.getAttribute('aria-label') || table.getAttribute('summary') || '';
          if (!title) {
            const cap = table.querySelector('caption');
            if (cap) title = cap.textContent.trim();
          }
          if (!title) {
            let el = table.previousElementSibling;
            while (el && !/^H[1-6]$/.test(el.tagName)) el = el.previousElementSibling;
            if (el) title = el.textContent.trim();
          }

          // Extract rows
          const rows = [];
          trs.forEach(tr => {
            const cells = [];
            tr.querySelectorAll('th, td').forEach(td => {
              let val = td.textContent.trim().replace(/\s+/g, ' ');
              const colspan = parseInt(td.getAttribute('colspan') || '1');
              cells.push(val);
              for (let c = 1; c < colspan; c++) cells.push('');
            });
            if (cells.length > 0) rows.push(cells);
          });

          if (rows.length === 0) return;

          // Normalize columns
          const maxCols = Math.max(...rows.map(r => r.length));
          rows.forEach(r => { while (r.length < maxCols) r.push(''); });

          // Default sheet names
          const sheetNum = sheets.length + 1;
          const name = (title && title.length <= 25) ? title : ('表格' + sheetNum);

          sheets.push({ name, rows });
        });

        return sheets;
      }
    });

    const sheets = results[0]?.result || [];

    if (sheets.length === 0) {
      panel.innerHTML = '<p style="font-size:0.85rem;color:var(--muted);padding:16px;text-align:center;">当前页面未找到表格<br><br>💡 试试打开有表格的网页（如股票、数据网站等）</p>';
      return;
    }

    // Show what we found
    panel.innerHTML = `
      <div style="padding:8px 0;">
        <p style="font-size:0.85rem;color:var(--muted);text-align:center;margin-bottom:12px;">
          找到 <strong>${sheets.length}</strong> 个表格，共 <strong>${sheets.reduce((s,sh) => s + sh.rows.length, 0)}</strong> 行数据
        </p>
        <div style="max-height:150px;overflow-y:auto;margin-bottom:12px;">
          ${sheets.map(s => `<div style="display:flex;justify-content:space-between;padding:6px 10px;font-size:0.8rem;border-bottom:1px solid #eee;"><span>📊 ${s.name}</span><span style="color:var(--muted)">${s.rows.length}行 × ${(s.rows[0]||[]).length}列</span></div>`).join('')}
        </div>
        <button id="btn-download-xlsx" style="width:100%;padding:12px;background:#16a34a;color:#fff;border:none;border-radius:8px;font-size:0.95rem;font-weight:600;cursor:pointer;">
          ⬇ 一键下载全部表格 (.xlsx)
        </button>
      </div>
    `;

    // Bind download
    document.getElementById('btn-download-xlsx').addEventListener('click', () => {
      try {
        const buf = XLSXBuilder.build(sheets);
        const blob = new Blob([buf], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        const host = new URL(tab.url).hostname.replace(/^www\./, '').replace(/\./g, '_');
        a.download = `handly-${host}-${new Date().toISOString().slice(0,10)}.xlsx`;
        a.href = url;
        document.body.appendChild(a); a.click(); document.body.removeChild(a);
        URL.revokeObjectURL(url);
        showStatus(`✅ 已导出 ${sheets.length} 个表格到 Excel！`, 'success');
      } catch (err) {
        showStatus('❌ 导出失败: ' + err.message, 'error');
      }
    });

  } catch (err) {
    showStatus('❌ 无法访问页面: ' + err.message, 'error');
  }
});
