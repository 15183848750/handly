// Handly — Popup Controller

// ========== UI State ==========
const $ = (sel) => document.querySelector(sel);
const $$ = (sel) => document.querySelectorAll(sel);

function togglePanel(panelId) {
  // Close all panels first
  $$('.sub-panel, .table-list').forEach(p => p.classList.remove('active'));
  // Open target
  const panel = $(`#${panelId}`);
  if (panel) panel.classList.add('active');
}

function showStatus(msg, type = 'loading') {
  const el = $('#status');
  el.className = `status ${type}`;
  el.textContent = msg;
  setTimeout(() => { el.className = 'status'; }, 3000);
}

// ========== Screenshot ==========
$('#tool-screenshot').addEventListener('click', () => {
  togglePanel('panel-screenshot');
});

$$('.preset-btn').forEach(btn => {
  btn.addEventListener('click', async () => {
    const preset = btn.dataset.preset;
    showStatus('正在截图...', 'loading');

    try {
      const dataUrl = await ScreenshotBeautifier.capture(preset);
      const presetName = ScreenshotBeautifier.presets[preset].name;
      ScreenshotBeautifier.download(dataUrl, `handly-${presetName}-${Date.now()}.png`);
      showStatus('✅ 截图已保存！', 'success');
    } catch (err) {
      showStatus('❌ ' + err.message, 'error');
    }
  });
});

// ========== Table Export ==========
$('#tool-export').addEventListener('click', async () => {
  togglePanel('panel-export');

  // Scan tables on the current page
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    const results = await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: () => {
        // Inline TableExporter scan (can't import modules in executeScript)
        const tables = document.querySelectorAll('table');
        const result = [];
        tables.forEach((table, i) => {
          if (table.offsetParent === null && table.clientHeight === 0) return;
          const rows = table.querySelectorAll('tr');
          if (rows.length < 2) return;
          let title = table.getAttribute('aria-label') || table.getAttribute('summary') || '';
          if (!title) {
            const caption = table.querySelector('caption');
            if (caption) title = caption.textContent.trim();
          }
          if (!title) {
            let el = table.previousElementSibling;
            while (el && !/^H[1-6]$/.test(el.tagName)) el = el.previousElementSibling;
            if (el) title = el.textContent.trim();
          }
          const headerRow = table.querySelector('thead tr, tr:first-child');
          const colCount = headerRow ? headerRow.querySelectorAll('th, td').length : 0;
          result.push({
            index: i,
            title: title || `表格 ${i + 1}`,
            rows: rows.length,
            cols: colCount
          });
        });
        return result;
      }
    });

    const tables = results[0]?.result || [];
    const panel = $('#panel-export');

    if (tables.length === 0) {
      panel.innerHTML = '<p style="font-size:0.8rem;color:var(--muted);padding:8px;">当前页面未找到表格</p>';
      return;
    }

    panel.innerHTML = tables.map(t => `
      <div class="table-item" data-table-index="${t.index}">
        <span><strong>${t.title}</strong></span>
        <span class="meta">${t.rows}行 × ${t.cols}列 ▸</span>
      </div>
    `).join('');

    // Bind click handlers
    panel.querySelectorAll('.table-item').forEach(item => {
      item.addEventListener('click', async () => {
        const tableIndex = parseInt(item.dataset.tableIndex);
        showStatus('正在导出...', 'loading');

        try {
          const exportResult = await chrome.scripting.executeScript({
            target: { tabId: tab.id },
            func: (index) => {
              const tables = document.querySelectorAll('table');
              let found = null;
              let count = 0;
              for (const t of tables) {
                if (t.offsetParent === null && t.clientHeight === 0) continue;
                const rows = t.querySelectorAll('tr');
                if (rows.length < 2) continue;
                if (count === index) { found = t; break; }
                count++;
              }
              if (!found) return { error: 'Table not found' };

              const data = [];
              found.querySelectorAll('tr').forEach(tr => {
                const cells = [];
                tr.querySelectorAll('th, td').forEach(td => {
                  cells.push(td.textContent.trim().replace(/\s+/g, ' ').replace(/"/g, '""'));
                });
                if (cells.length > 0) data.push(cells);
              });

              const csv = '\uFEFF' + data.map(row =>
                row.map(cell => `"${cell}"`).join(',')
              ).join('\n');

              return { csv, rowCount: data.length };
            },
            args: [tableIndex]
          });

          const { csv, rowCount, error } = exportResult[0]?.result || {};
          if (error) { showStatus('❌ ' + error, 'error'); return; }

          // Download via blob
          const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
          const url = URL.createObjectURL(blob);
          const link = document.createElement('a');
          link.href = url;
          const tableInfo = tables.find(t => t.index === tableIndex);
          link.download = `handly-${(tableInfo?.title || 'export').replace(/[^\w\u4e00-\u9fff]/g, '-')}.csv`;
          link.click();
          URL.revokeObjectURL(url);

          showStatus(`✅ 已导出 ${rowCount} 行数据！`, 'success');
        } catch (err) {
          showStatus('❌ 导出失败: ' + err.message, 'error');
        }
      });
    });

  } catch (err) {
    showStatus('❌ 无法访问当前页面: ' + err.message, 'error');
  }
});
