// Handly — Background Service Worker
// Handles extension lifecycle and messaging

chrome.runtime.onInstalled.addListener((details) => {
  if (details.reason === 'install') {
    console.log('Handly installed — v1.0.0');
    // Open welcome page
    chrome.tabs.create({ url: 'https://handly.cc' });
  }
});

// Listen for messages from popup
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'captureScreenshot') {
    chrome.tabs.captureVisibleTab(null, { format: 'png' }, (dataUrl) => {
      sendResponse({ dataUrl });
    });
    return true; // async response
  }
});
