// Handly — Popup Controller v1.1

const $ = (sel) => document.querySelector(sel);
const $$ = (sel) => document.querySelectorAll(sel);

// Get the real current tab (the one user is viewing, not the popup)
async function getCurrentTab() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  return tab;
}

function togglePanel(panelId) {
  $$('.sub-panel, .table-list').forEach(p => p.classList.remove('active'));
  const panel = $(`#${panelId}`);
  if (panel) panel.classList.add('active');
}

function showStatus(msg, type = 'loading') {
  const el = $('#status');
  el.className = `status ${type}`;
  el.textContent = msg;
  if (type === 'success' || type === 'error') {
    setTimeout(() => { el.className = 'status'; el.textContent = ''; }, 3500);
  }
}

// ========== Screenshot ==========
$('#tool-screenshot').addEventListener('click', () => {
  togglePanel('panel-screenshot');
});

$$('.preset-btn').forEach(btn => {
  btn.addEventListener('click', async () => {
    const preset = btn.dataset.preset;
    showStatus('正在截图...', 'loading');

    try {
      // Capture visible tab
      const tab = await getCurrentTab();
      const dataUrl = await chrome.tabs.captureVisibleTab(tab.windowId, {
        format: 'png'
      });

      // Process screenshot with selected preset
      const config = ScreenshotBeautifier.presets[preset] || ScreenshotBeautifier.presets.clean;
      const img = await ScreenshotBeautifier.loadImage(dataUrl);

      const scale = config.scale;
      const padding = config.padding;
      const radius = config.radius;

      const canvasWidth = img.width * scale + padding * 2;
      const canvasHeight = img.height * scale + padding * 2;

      const canvas = document.createElement('canvas');
      canvas.width = canvasWidth;
      canvas.height = canvasHeight;
      const ctx = canvas.getContext('2d');

      // Background
      if (config.bg) {
        if (config.bg.startsWith('linear-gradient')) {
          const match = config.bg.match(/linear-gradient\((\d+)deg,\s*(.+)\)/);
          if (match) {
            const angle = parseInt(match[1]) * Math.PI / 180;
            const colors = match[2].split(',').map(s => s.trim());
            const x1 = canvasWidth / 2 - Math.cos(angle) * canvasWidth / 2;
            const y1 = canvasHeight / 2 - Math.sin(angle) * canvasHeight / 2;
            const x2 = canvasWidth / 2 + Math.cos(angle) * canvasWidth / 2;
            const y2 = canvasHeight / 2 + Math.sin(angle) * canvasHeight / 2;
            const grad = ctx.createLinearGradient(x1, y1, x2, y2);
            colors.forEach((c, i) => grad.addColorStop(i / (colors.length - 1), c));
            ctx.fillStyle = grad;
          } else {
            ctx.fillStyle = config.bg;
          }
        } else {
          ctx.fillStyle = config.bg;
        }
        ctx.fillRect(0, 0, canvasWidth, canvasHeight);
      }

      // Rounded clip
      if (radius > 0) {
        ctx.beginPath();
        ScreenshotBeautifier.roundRect(ctx, padding, padding,
          img.width * scale, img.height * scale, radius);
        ctx.closePath();
        ctx.clip();
      }

      // Shadow
      if (config.shadow) {
        ctx.shadowColor = 'rgba(0, 0, 0, 0.15)';
        ctx.shadowBlur = 30;
        ctx.shadowOffsetX = 0;
        ctx.shadowOffsetY = 8;
      }

      ctx.drawImage(img, padding, padding, img.width * scale, img.height * scale);
      const resultUrl = canvas.toDataURL('image/png');

      // Download
      const presetName = config.name;
      ScreenshotBeautifier.download(resultUrl, `handly-${presetName}-${Date.now()}.png`);
      showStatus('✅ 截图已保存！', 'success');
    } catch (err) {
      console.error('Screenshot error:', err);
      showStatus('❌ 截图失败: ' + err.message, 'error');
    }
  });
});

// ========== Table Export ==========
$('#tool-export').addEventListener('click', async () => {
  togglePanel('panel-export');
  const panel = $('#panel-export');
  panel.innerHTML = '<p style="font-size:0.8rem;color:var(--muted);padding:8px;">正在扫描表格...</p>';
  showStatus('正在扫描当前页面...', 'loading');

  try {
    const tab = await getCurrentTab();

    // Inject table scanner into the current page
    const results = await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: () => {
        const tables = document.querySelectorAll('table');
        const result = [];
        tables.forEach((table, i) => {
          // Skip hidden/trivial tables
          if (table.offsetParent === null && table.clientHeight === 0) return;
          const rows = table.querySelectorAll('tr');
          if (rows.length < 2) return;

          let title = table.getAttribute('aria-label') || table.getAttribute('summary') || '';
          if (!title) {
            const caption = table.querySelector('caption');
            if (caption) title = caption.textContent.trim();
          }
          if (!title) {
            let el = table.previousElementSibling;
            while (el && !/^H[1-6]$/.test(el.tagName)) el = el.previousElementSibling;
            if (el) title = el.textContent.trim();
          }

          const headerRow = table.querySelector('thead tr, tr:first-child');
          const colCount = headerRow ? headerRow.querySelectorAll('th, td').length : 0;

          result.push({
            index: i,
            title: title || '表格 ' + (i + 1),
            rows: rows.length,
            cols: colCount
          });
        });
        return result;
      }
    });

    const tables = results[0]?.result || [];

    if (tables.length === 0) {
      panel.innerHTML = '<p style="font-size:0.8rem;color:var(--muted);padding:8px;">当前页面未找到表格<br><br>试试打开一个有表格的页面（如维基百科、股票网站等）</p>';
      return;
    }

    // Render table list
    panel.innerHTML = tables.map(t =>
      `<div class="table-item" data-table-index="${t.index}">
        <span><strong>📊 ${t.title}</strong></span>
        <span class="meta">${t.rows}行 × ${t.cols}列 ▸</span>
      </div>`
    ).join('');

    // Bind export handlers
    panel.querySelectorAll('.table-item').forEach(item => {
      item.addEventListener('click', async () => {
        const tableIndex = parseInt(item.dataset.tableIndex);
        showStatus('正在导出...', 'loading');

        try {
          const exportResult = await chrome.scripting.executeScript({
            target: { tabId: tab.id },
            func: (index) => {
              const tables = document.querySelectorAll('table');
              let found = null, count = 0;
              for (const t of tables) {
                if (t.offsetParent === null && t.clientHeight === 0) continue;
                const rows = t.querySelectorAll('tr');
                if (rows.length < 2) continue;
                if (count === index) { found = t; break; }
                count++;
              }
              if (!found) return { error: '表格未找到，请刷新后重试' };

              const data = [];
              found.querySelectorAll('tr').forEach(tr => {
                const cells = [];
                tr.querySelectorAll('th, td').forEach(td => {
                  cells.push(td.textContent.trim()
                    .replace(/\s+/g, ' ').replace(/"/g, '""'));
                });
                if (cells.length > 0) data.push(cells);
              });

              const csv = '\uFEFF' + data.map(row =>
                row.map(cell => '"' + cell + '"').join(',')
              ).join('\n');

              return { csv, rowCount: data.length };
            },
            args: [tableIndex]
          });

          const { csv, rowCount, error } = exportResult[0]?.result || {};
          if (error) { showStatus('❌ ' + error, 'error'); return; }

          const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
          const url = URL.createObjectURL(blob);
          const a = document.createElement('a');
          a.href = url;
          const tableInfo = tables.find(t => t.index === tableIndex);
          const fname = (tableInfo?.title || 'export').replace(/[^\w\u4e00-\u9fff-]/g, '_');
          a.download = 'handly-' + fname + '.csv';
          a.click();
          URL.revokeObjectURL(url);

          showStatus('✅ 已导出 ' + rowCount + ' 行数据！', 'success');
        } catch (err) {
          console.error('Export error:', err);
          showStatus('❌ 导出失败: ' + err.message, 'error');
        }
      });
    });

  } catch (err) {
    console.error('Table scan error:', err);
    showStatus('❌ 无法访问页面: ' + err.message, 'error');
  }
});
