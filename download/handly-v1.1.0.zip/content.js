// Handly — Content Script
// Injected into every page. Provides table scanning and screenshot data.

// Expose Handly API to page context (useful for future features)
window.__handly = {
  version: '1.0.0',
  tableCount: () => document.querySelectorAll('table').length
};
