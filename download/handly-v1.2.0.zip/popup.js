// Handly — Popup Controller v1.2

const $ = (sel) => document.querySelector(sel);
const $$ = (sel) => document.querySelectorAll(sel);

async function getCurrentTab() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  return tab;
}

function togglePanel(panelId) {
  $$('.sub-panel, .table-list').forEach(p => p.classList.remove('active'));
  const panel = $(`#${panelId}`);
  if (panel) panel.classList.add('active');
}

function showStatus(msg, type = 'loading') {
  const el = $('#status');
  el.className = `status ${type}`;
  el.textContent = msg;
  if (type === 'success' || type === 'error') {
    setTimeout(() => { el.className = 'status'; el.textContent = ''; }, 3500);
  }
}

// ========== Screenshot (rewritten — no clip, no shadow on tainted canvas) ==========
$('#tool-screenshot').addEventListener('click', () => {
  togglePanel('panel-screenshot');
});

$$('.preset-btn').forEach(btn => {
  btn.addEventListener('click', async () => {
    const preset = btn.dataset.preset;
    showStatus('正在截图...', 'loading');

    try {
      // Capture — null windowId lets Chrome pick the current window
      const dataUrl = await chrome.tabs.captureVisibleTab(null, { format: 'png' });

      // Load image
      const img = await new Promise((resolve, reject) => {
        const image = new Image();
        image.onload = () => resolve(image);
        image.onerror = () => reject(new Error('图片加载失败'));
        image.src = dataUrl;
      });

      const config = ScreenshotBeautifier.presets[preset] || ScreenshotBeautifier.presets.clean;
      const P = config.padding;
      const R = config.radius;
      const W = img.width + P * 2;
      const H = img.height + P * 2;

      const canvas = document.createElement('canvas');
      canvas.width = W;
      canvas.height = H;
      const ctx = canvas.getContext('2d');

      // Draw background first
      if (config.bg) {
        ctx.fillStyle = config.bg.startsWith('linear-gradient')
          ? parseGradient(ctx, config.bg, W, H)
          : config.bg;
        ctx.fillRect(0, 0, W, H);
      }

      // Draw image with padding
      // NO clip — draw shadow on a separate pass instead
      if (R > 0 && config.shadow) {
        // Draw shadow underlay
        ctx.save();
        ctx.shadowColor = 'rgba(0, 0, 0, 0.2)';
        ctx.shadowBlur = 24;
        ctx.shadowOffsetX = 0;
        ctx.shadowOffsetY = 6;
        ctx.fillStyle = '#000';
        ctx.beginPath();
        roundRectPath(ctx, P, P, img.width, img.height, R);
        ctx.fill();
        ctx.restore();
      }

      // Draw image with rounded corner mask
      ctx.save();
      ctx.beginPath();
      roundRectPath(ctx, P, P, img.width, img.height, R);
      ctx.clip();
      ctx.drawImage(img, P, P, img.width, img.height);
      ctx.restore();

      // Convert and download
      const resultUrl = canvas.toDataURL('image/png');
      const a = document.createElement('a');
      a.download = `handly-${config.name}-${Date.now()}.png`;
      a.href = resultUrl;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);

      showStatus('✅ 截图已保存！', 'success');
    } catch (err) {
      console.error('Screenshot error:', err);
      showStatus('❌ 截图失败: ' + (err.message || String(err)), 'error');
    }
  });
});

function roundRectPath(ctx, x, y, w, h, r) {
  ctx.moveTo(x + r, y);
  ctx.lineTo(x + w - r, y);
  ctx.quadraticCurveTo(x + w, y, x + w, y + r);
  ctx.lineTo(x + w, y + h - r);
  ctx.quadraticCurveTo(x + w, y + h, x + w - r, y + h);
  ctx.lineTo(x + r, y + h);
  ctx.quadraticCurveTo(x, y + h, x, y + h - r);
  ctx.lineTo(x, y + r);
  ctx.quadraticCurveTo(x, y, x + r, y);
}

function parseGradient(ctx, css, W, H) {
  const m = css.match(/linear-gradient\((\d+)deg,\s*(.+)\)/);
  if (!m) return css;
  const angle = parseInt(m[1]) * Math.PI / 180;
  const colors = m[2].split(',').map(s => s.trim());
  const grad = ctx.createLinearGradient(
    W/2 - Math.cos(angle) * W/2,
    H/2 - Math.sin(angle) * H/2,
    W/2 + Math.cos(angle) * W/2,
    H/2 + Math.sin(angle) * H/2
  );
  colors.forEach((c, i) => grad.addColorStop(i / (colors.length - 1), c));
  return grad;
}

// ========== Table Export (rewritten — preserve full table structure) ==========
$('#tool-export').addEventListener('click', async () => {
  togglePanel('panel-export');
  const panel = $('#panel-export');
  panel.innerHTML = '<p style="font-size:0.8rem;color:var(--muted);padding:8px;">正在扫描表格...</p>';
  showStatus('正在扫描当前页面...', 'loading');

  try {
    const tab = await getCurrentTab();

    // Scan all tables on page
    const results = await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: () => {
        const tables = document.querySelectorAll('table');
        const result = [];
        tables.forEach((table, i) => {
          if (table.offsetParent === null && table.clientHeight === 0) return;
          const rows = table.querySelectorAll('tr');
          if (rows.length < 2) return;

          let title = table.getAttribute('aria-label') || table.getAttribute('summary') || '';
          if (!title) {
            const cap = table.querySelector('caption');
            if (cap) title = cap.textContent.trim();
          }
          if (!title) {
            let el = table.previousElementSibling;
            while (el && !/^H[1-6]$/.test(el.tagName)) el = el.previousElementSibling;
            if (el) title = el.textContent.trim();
          }
          const hdr = table.querySelector('thead tr, tr:first-child');
          const colCount = hdr ? hdr.querySelectorAll('th, td').length : 0;

          result.push({
            index: i,
            title: title || '表格 ' + (i + 1),
            rows: rows.length,
            cols: colCount
          });
        });
        return result;
      }
    });

    const tables = results[0]?.result || [];

    if (tables.length === 0) {
      panel.innerHTML = '<p style="font-size:0.8rem;color:var(--muted);padding:12px;text-align:center;">当前页面未找到表格<br><br>💡 试试打开维基百科、股票网站等有表格的页面</p>';
      return;
    }

    // Render table list
    panel.innerHTML = tables.map(t =>
      `<div class="table-item" data-table-index="${t.index}">
        <span><strong>📊 ${t.title}</strong></span>
        <span class="meta">${t.rows}行 × ${t.cols}列 ▸</span>
      </div>`
    ).join('');

    // Bind export — extract full HTML table and offer CSV
    panel.querySelectorAll('.table-item').forEach(item => {
      item.addEventListener('click', async () => {
        const tableIndex = parseInt(item.dataset.tableIndex);
        showStatus('正在导出...', 'loading');

        try {
          const exportResult = await chrome.scripting.executeScript({
            target: { tabId: tab.id },
            func: (index) => {
              // Find the target table
              const tables = document.querySelectorAll('table');
              let found = null, count = 0;
              for (const t of tables) {
                if (t.offsetParent === null && t.clientHeight === 0) continue;
                if (t.querySelectorAll('tr').length < 2) continue;
                if (count === index) { found = t; break; }
                count++;
              }
              if (!found) return { error: '表格未找到' };

              // Clone the table to preserve structure
              const clone = found.cloneNode(true);

              // Get clean HTML (remove scripts, event handlers)
              clone.querySelectorAll('script, style, noscript').forEach(el => el.remove());
              clone.querySelectorAll('[onclick], [onchange], [onfocus]').forEach(el => {
                el.removeAttribute('onclick');
                el.removeAttribute('onchange');
                el.removeAttribute('onfocus');
              });

              // Extract inline styles for preservation
              const tableHTML = clone.outerHTML;

              // Also build CSV version from the same table
              const csvRows = [];
              found.querySelectorAll('tr').forEach(tr => {
                const cells = [];
                tr.querySelectorAll('th, td').forEach(td => {
                  let val = td.textContent.trim().replace(/\s+/g, ' ').replace(/"/g, '""');
                  // Handle colspan — pad empty cells
                  const colspan = parseInt(td.getAttribute('colspan') || '1');
                  cells.push(val);
                  for (let c = 1; c < colspan; c++) cells.push('');
                });
                if (cells.length > 0) csvRows.push(cells);
              });

              // Normalize row lengths (pad shorter rows)
              const maxCols = Math.max(...csvRows.map(r => r.length));
              csvRows.forEach(r => {
                while (r.length < maxCols) r.push('');
              });

              const csv = '\uFEFF' + csvRows.map(row =>
                row.map(c => '"' + c + '"').join(',')
              ).join('\n');

              return {
                html: tableHTML,
                csv: csv,
                rowCount: csvRows.length,
                colCount: maxCols
              };
            },
            args: [tableIndex]
          });

          const { html, csv, rowCount, colCount, error } = exportResult[0]?.result || {};
          if (error) { showStatus('❌ ' + error, 'error'); return; }

          const tableInfo = tables.find(t => t.index === tableIndex);
          const baseName = 'handly-' + (tableInfo?.title || 'table').replace(/[^\w\u4e00-\u9fff-]/g, '_');

          // Download HTML (preserves full structure)
          const htmlBlob = new Blob([
            '<!DOCTYPE html><html><head><meta charset="UTF-8"><title>' +
            (tableInfo?.title || 'Exported Table') +
            '</title><style>table{border-collapse:collapse;width:100%;}th,td{border:1px solid #ddd;padding:8px;text-align:left;}th{background:#f5f5f5;}</style></head><body>' +
            html + '</body></html>'
          ], { type: 'text/html;charset=utf-8;' });

          const htmlUrl = URL.createObjectURL(htmlBlob);
          const a1 = document.createElement('a');
          a1.href = htmlUrl;
          a1.download = baseName + '.html';
          a1.click();
          URL.revokeObjectURL(htmlUrl);

          // Also download CSV
          const csvBlob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
          const csvUrl = URL.createObjectURL(csvBlob);
          const a2 = document.createElement('a');
          a2.href = csvUrl;
          a2.download = baseName + '.csv';
          a2.click();
          URL.revokeObjectURL(csvUrl);

          showStatus(`✅ 已导出 ${rowCount}行 × ${colCount}列 (HTML + CSV)`, 'success');
        } catch (err) {
          console.error('Export error:', err);
          showStatus('❌ 导出失败: ' + err.message, 'error');
        }
      });
    });

  } catch (err) {
    console.error('Table scan error:', err);
    showStatus('❌ 无法访问页面: ' + err.message, 'error');
  }
});
